#include <stdio.h>														
#include <stdlib.h>
#include <string.h>
#include "game.h"
#include "player.h"

#define MAX 12

STATUS load_additional_spaces(Game* game, char* filename){


	if(game_load_spaces(Game* game, char* filename)==ERROR){
	
		return ERROR;
	
	}
	else{
	
		for (i = 0; i < MAX; i++) {
			game->spaces[i] = NULL;
		}
		
		
	
		
	
	
	
	
	}


	return OK;
}
