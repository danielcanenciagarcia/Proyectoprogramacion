/** 
 * @brief It defines common types
 * 
 * @file types.h
 * @author Profesores PPROG
 * @version 1.0 
 * @date 13-01-2015
 * @copyright GNU Public License
 */

/* Primero incluimos la estructura de nuestro archivo de cabezera y nuestros respectivos archivos de encabezamiento. */

#ifndef TYPES_H					 
#define TYPES_H

/* Seguidamente, se definen varias macros utilizadas con posterioridad en nuestros archivos de implementación. */

#define WORD_SIZE 1000  			
#define NO_ID -1

typedef long Id;

/* Para terminar se definen algunas enumeraciones utilizadas para definir el tipo de numerosas funciones en diferentes archivos de implementación.
   Notese que la enumeración Direction no es utilizada en ninguno de los anteriores. */

typedef enum {FALSE, TRUE} BOOL;    
typedef enum {ERROR, OK} STATUS;

typedef enum {N, S, E, W} DIRECTION;

#endif

