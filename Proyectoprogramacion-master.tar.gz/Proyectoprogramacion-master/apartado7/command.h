/** 
 * @brief It implements the command interpreter
 * 
 * @file command.h
 * @author Profesores PPROG
 * @version 1.0 
 * @date 19-12-2014 
 * @copyright GNU Public License
 */

/* Primero incluimos la estructura de nuestro archivo de cabezera */ 

#ifndef COMMAND_H          
#define COMMAND_H

/* Enumeración tipo T_Command */

typedef enum enum_Command {NO_CMD = -1,UNKNOWN,QUIT,NEXT,BACK} T_Command;   

/* Es necesario tomar constancia de las funciones utilizadas posteriormente en nuestro archivo de implementación(.c) */

T_Command get_user_input();    

#endif
